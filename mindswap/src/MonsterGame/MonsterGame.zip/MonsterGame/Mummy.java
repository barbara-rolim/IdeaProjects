package MonsterGame;

public class Mummy extends Monster {
    public Mummy() {
        super(MonsterType.MUMMY, 12, "Mummy");
    }

    @Override
    public void attack(Monster target) {
        target.setHealthPoints(getHealthPoints() - 4);
        
    }
}
