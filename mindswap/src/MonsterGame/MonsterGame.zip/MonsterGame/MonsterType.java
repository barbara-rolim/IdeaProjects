package MonsterGame;

public enum MonsterType {
    WEREWOLF,
    MUMMY,
    VAMPIRE
}
